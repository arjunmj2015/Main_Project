Cohort Code : INTQEA22QE004
Group No. : 2
Project Type :MAIN PROJECT
Project Title: VALIDATION OF Trutime 
------------------------------------------------------------
------------------------------------------------------------

***************************  MAIN PROJECT ***********************************

Problem Statement:
                 Validation of Timesheet for current week, previous week and previous to previous week

Detailed Description: 

	1.Open url-> be.cognizant.com
	2.Login using cognizant credentials
	3.After opening of be.cognizant.com fetch the title of page and the name of person
	4.Search for trutime in the search bar of be.cognizant homepage and then open timesheet window
        5.Now capture and  print all the current week of truetime in the console.


Technology/Automation Tools used:
1.Selenium Webdriver and it's concepts
2.TestNG Framework and it's concepts
3.Data Driven approach
4.Core Java Concepts
5.Maven/Apache POI tools
6.Extent Report/TestNG Report/Customized Report
7.Cross Browser Testing Concepts
8.Property file concepts
              

Browser Options:
	1.Chrome
	2.Firefox
	(The browser is mentioned in the testng.xml,to run the various browser make changes in value field).


Structure Details:
	1.src/main/java:
		Base Package->Browser,Reusable Methods,Screenshot,Config.properties.
	2.Pages package:
		-> TimeSheet.java
	3.Utils package:
		ExtentReportManager.
		(This package contain extent report files to create an extent report).
	4.src/test/java:
		TestSuites package-> timesheet.java
		(This file contain the TestNG script to automate the code).
        5.src/test/resources:
              MS Excel file-> Data.xlsx

Readme:It contains the problem statement and detailed explanation about project file.

Reports:It contains the extent report for the automated project file.

Screenshot:It contains the screenshot taken during the execution of the program.

Team Members                   Employee Id
-------------                 -------------- 
Arjun M J                      2174174